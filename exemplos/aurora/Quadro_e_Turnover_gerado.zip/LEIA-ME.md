# Quadro e Turnover — como tornar o protótipo real

Gerado pelo Deidara a partir do `argila.json` aprovado por **Teste**
em 27/10/2026 12:43.

## O que tem nesta pasta

| Arquivo | Para quê |
|---|---|
| `Quadro_e_Turnover.pbip` | o projeto Power BI: abra no Power BI Desktop |
| `Quadro_e_Turnover.SemanticModel/` | o modelo (tabelas, relacionamentos, medidas) em TMDL |
| `Quadro_e_Turnover.Report/` | as páginas e os visuais, na mesma posição do protótipo |
| `sql/01_views.sql` | as views que o modelo lê (schema `bi`) |
| `sql/02_conferencia.sql` | o total de cada indicador direto no banco (geral e por ano), para homologar |
| `sql/03_qualidade.sql` | chave repetida, órfãos e datas fora do calendário: tudo tem que dar zero |
| `docs/dicionario_indicadores.md` | definição, fórmula, origem e prova de cada número |
| `docs/medidas.dax` | as medidas em texto (referência) |
| `prototipo.html` | o protótipo aprovado |

## Passo a passo

1. **Banco (DBA, SQL Server 2016 SP1+).** Revise e rode `sql/01_views.sql` no banco `AURORA`. Ele cria o
   schema `bi` e uma view por tabela do modelo. Dê `SELECT` no schema à conta do
   gateway (a linha comentada no fim do arquivo).
2. **Power BI Desktop** (versão de 2024 em diante). Abra `Quadro_e_Turnover.pbip`.
   Se aparecer aviso de recurso em versão prévia, habilite em *Arquivo > Opções > Recursos em
   versão prévia*: "Salvar como Projeto do Power BI (.pbip)" e "Armazenar relatórios no formato
   PBIR". Nas versões em que esses recursos já são padrão, não aparece nada.
3. **Conexão.** *Página Inicial > Transformar dados > Editar parâmetros*: preencha
   **Servidor** e **Banco** (hoje: `SERVIDOR-SQL` / `AURORA`). Depois *Atualizar*.
4. **Homologação.** Rode `sql/03_qualidade.sql` (tudo zero) e `sql/02_conferencia.sql` e compare cada total com o cartão do
   painel, sem nenhum filtro marcado. Divergência = não publique; volte ao dono do indicador.
5. **Gerar o .pbix.** *Arquivo > Salvar como* e escolha "Arquivo do Power BI (*.pbix)".
   O `.pbip` continua sendo a fonte versionável (git); o `.pbix` é o que vai para o serviço.
6. **Publicar.** *Página Inicial > Publicar* no workspace do time. No serviço, configure o
   gateway e a atualização agendada.

## Pendências registradas na aprovação

- relacionamentos dColaborador -> dCargo: dCargo chega em fDesligamento através de dColaborador: o corte por dCargo mostra o valor ATUAL do cadastro de dColaborador, não o da data do evento. Se a fato tiver o código histórico, ligue direto nela; senão, registre isso na definição do indicador
- relacionamentos dColaborador -> dEmpresa: dEmpresa chega em fDesligamento através de dColaborador: o corte por dEmpresa mostra o valor ATUAL do cadastro de dColaborador, não o da data do evento. Se a fato tiver o código histórico, ligue direto nela; senão, registre isso na definição do indicador

## Regras desta entrega

- Nenhum dado do banco foi lido para gerar estes arquivos: só a estrutura (via Vegapunk).
- Toda tabela, coluna e ligação aqui veio do `detalhar` do Vegapunk; as ligações trazem a
  prova no dicionário de indicadores.
- Mudou algo? Edite o `argila.json`, gere o protótipo de novo, aprove e gere outra vez. Não
  edite o `.pbip` à mão se quiser continuar gerando pelo Deidara.
