# Quadro e Turnover — como tornar o protótipo real

Gerado pelo Deidara a partir do `argila.json` aprovado por **Teste**
em 27/10/2026 15:49.

## O que tem nesta pasta

| Arquivo | Para quê |
|---|---|
| `Quadro_e_Turnover.pbip` | o projeto Power BI: abra no Power BI Desktop |
| `Quadro_e_Turnover.SemanticModel/` | o modelo (tabelas, relacionamentos, medidas) em TMDL |
| `Quadro_e_Turnover.Report/` | as páginas e os visuais, na mesma posição do protótipo |
| `sql/erp/01_views.sql` | as views que o modelo lê da fonte erp |
| `sql/erp/02_conferencia.sql` | o total de cada indicador no banco (geral e por ano) |
| `sql/erp/03_qualidade.sql` | chave repetida, órfãos, datas fora do calendário: tudo zero |
| `docs/dicionario_indicadores.md` | definição, fórmula, origem e prova de cada número |
| `docs/medidas.dax` | as medidas em texto (referência) |
| `prototipo.html` | o protótipo aprovado |

## Passo a passo

1. **Banco erp (DBA, SQL Server 2016 SP1+).** Revise e rode `sql/erp/01_views.sql` no banco
   `AURORA`. Ele cria o schema `bi` e uma view por tabela. Dê `SELECT` no schema à conta do
   gateway (linha comentada no fim do arquivo). Parâmetros no Power BI: **erp_Servidor** e **erp_Banco**.
2. **Fonte metas (Power Query).** A tabela fMeta usa a mesma
   consulta Power Query de origem (arquivo, SharePoint, API...). No primeiro *Atualizar*, o Desktop pede a credencial
   dessa fonte. Arquivo em pasta da rede precisa de gateway no serviço; arquivo no SharePoint/OneDrive, não.
3. **Power BI Desktop** (versão de 2024 em diante). Abra `Quadro_e_Turnover.pbip`.
   Se aparecer aviso de recurso em versão prévia, habilite em *Arquivo > Opções > Recursos em
   versão prévia*: "Salvar como Projeto do Power BI (.pbip)" e "Armazenar relatórios no formato
   PBIR". Nas versões em que esses recursos já são padrão, não aparece nada.
4. **Conexão.** *Página Inicial > Transformar dados > Editar parâmetros*: confira cada parâmetro. Depois
   *Atualizar*.
5. **Homologação.** Rode `03_qualidade.sql` (tudo zero) e `02_conferencia.sql` de cada fonte SQL e compare cada total com o cartão do painel, sem filtro. Ligações declaradas (sem prova na fonte): fMeta[Cód. Empresa] → dEmpresa[Cód. Empresa]. Confira se não há código repetido no lado "um" nem código sem par. Divergência = não publique; volte ao dono do indicador.
6. **Gerar o .pbix.** *Arquivo > Salvar como* e escolha "Arquivo do Power BI (*.pbix)".
   O `.pbip` continua sendo a fonte versionável (git); o `.pbix` é o que vai para o serviço.
7. **Publicar.** *Página Inicial > Publicar* no workspace do time. No serviço, configure o
   gateway (se houver fonte na rede ou banco local) e a atualização agendada.

## Pendências registradas na aprovação

- relacionamentos[4] fMeta -> dEmpresa: ligação DECLARADA por Time de Indicadores, sem prova na fonte (a planilha de metas usa o mesmo código de empresa do ERP): rode a receita de prova (`deidara.py receita prova`) ou confira na primeira atualização (chave repetida no lado um derruba a atualização; código sem par some do corte)
- página Turnover: o segmentador dCalendario[Ano] não filtra a medida inteira de "Meta de Turnover": ao escolher um valor, o número fica parado
- relacionamentos dColaborador -> dCargo: dCargo chega em fDesligamento através de dColaborador: o corte por dCargo mostra o valor ATUAL do cadastro de dColaborador, não o da data do evento. Se a fato tiver o código histórico, ligue direto nela; senão, registre isso na definição do indicador
- relacionamentos dColaborador -> dEmpresa: dEmpresa chega em fDesligamento através de dColaborador: o corte por dEmpresa mostra o valor ATUAL do cadastro de dColaborador, não o da data do evento. Se a fato tiver o código histórico, ligue direto nela; senão, registre isso na definição do indicador

## Regras desta entrega

- Nenhuma linha de dado foi lida para gerar estes arquivos: só a estrutura, pelas receitas do Deidara.
- Toda tabela, coluna e ligação aqui está no catálogo da fonte; cada ligação traz a prova (ou quem a
  declarou) no dicionário de indicadores.
- Mudou algo? Edite o `argila.json`, gere o protótipo de novo, aprove e gere outra vez. Não
  edite o `.pbip` à mão se quiser continuar gerando pelo Deidara.
