# Quadro e Turnover — dicionário de indicadores (versão 1.0)

Acompanhamento do quadro de colaboradores, da remuneração e dos desligamentos por cargo, empresa e motivo.

| Indicador | Definição | Fórmula (DAX) | Formato | Polaridade | Meta |
|---|---|---|---|---|---|
| **Headcount** | Colaboradores ativos no último dia do período: admitidos até a data menos desligados até a data. | `VAR _fim = MAX(dCalendario[Data]) VAR _entradas =     CALCULATE(         COUNTROWS(dColaborador),         dColaborador[Data de Admissão] <= _fim,         REMOVEFILTERS(dCalendario)     ) VAR _saidas =     CALCULATE(         COUNTROWS(fDesligamento),         fDesligamento[Data do Desligamento] <= _fim,         REMOVEFILTERS(dCalendario)     ) RETURN     IF(MIN(dCalendario[Data]) > TODAY(), BLANK(), _entradas - _saidas)` | inteiro | maior melhor | — |
| **HC Médio** | Média do headcount de fim de mês no período. | `IF(     MIN(dCalendario[Data]) > TODAY(),     BLANK(),     AVERAGEX(VALUES(dCalendario[Ano-Mês]), [Headcount]) )` | decimal | maior melhor | — |
| **Cadastros** | Colaboradores cadastrados (ativos e desligados). | `COUNTROWS(dColaborador)` | inteiro | maior melhor | — |
| **Remuneração Total** | Soma da remuneração mensal cadastrada (ativos e desligados). | `SUM(dColaborador[Remuneração])` | moeda | maior melhor | — |
| **Remuneração Média** | Remuneração total dividida pelo número de cadastros. | `DIVIDE([Remuneração Total], [Cadastros])` | moeda | maior melhor | — |
| **Desligamentos** | Desligamentos registrados no período. | `COUNTROWS(fDesligamento)` | inteiro | menor melhor | — |
| **Turnover** | Desligamentos do período divididos pelo headcount médio do período. | `DIVIDE([Desligamentos], [HC Médio])` | percentual | menor melhor | Meta Turnover |
| **Desligamentos Acum. Ano** | Desligamentos acumulados no ano. | `IF(     MIN(dCalendario[Data]) > TODAY(),     BLANK(),     TOTALYTD([Desligamentos], dCalendario[Data]) )` | inteiro | maior melhor | — |
| **Var. Desligamentos A/A** | Variação dos desligamentos contra o mesmo período do ano anterior. | `IF(     MIN(dCalendario[Data]) > TODAY(),     BLANK(),     VAR _atual = [Desligamentos]     VAR _anterior = CALCULATE([Desligamentos], SAMEPERIODLASTYEAR(dCalendario[Data]))     RETURN DIVIDE(_atual - _anterior, _anterior) )` | percentual | menor melhor | — |
| **Meta Turnover** | Meta de Turnover. | `0.05` | percentual | menor melhor | — |

## Origem dos dados

| Tabela do modelo | Tipo | Origem no banco | View |
|---|---|---|---|
| dColaborador | dimensao | F_FUNCIONARIO | [bi].[vw_dColaborador] |
| dCargo | dimensao | F_CARGO | [bi].[vw_dCargo] |
| dEmpresa | dimensao | N_EMPRESA | [bi].[vw_dEmpresa] |
| dMotivo | dimensao | F_MOTIVO_DESLIGAMENTO | [bi].[vw_dMotivo] |
| fDesligamento | fato | F_DESLIGAMENTO | [bi].[vw_fDesligamento] |
| dCalendario | dimensao | gerada no Power Query | — |

## Colunas

### dColaborador

| Coluna | Origem | Descrição |
|---|---|---|
| Matrícula | `F_FUNCIONARIO.MATRICULA` | Matricula do colaborador |
| Colaborador | `F_FUNCIONARIO.NOME` | Nome do colaborador |
| Data de Admissão | `F_FUNCIONARIO.DATAADMISSAO` | Data de admissao do colaborador |
| Remuneração | `F_FUNCIONARIO.VALORREMUNERACAO` | Valor da remuneracao mensal do colaborador |
| CODCARGO (oculta) | `F_FUNCIONARIO.CODCARGO` | Codigo do cargo do colaborador |
| CODEMPRESA (oculta) | `F_FUNCIONARIO.CODEMPRESA` | Codigo da empresa do colaborador |

### dCargo

| Coluna | Origem | Descrição |
|---|---|---|
| Cód. Cargo | `F_CARGO.CODCARGO` | Codigo do cargo |
| Cargo | `F_CARGO.DESCRICAOCARGO` | Descricao do cargo |

### dEmpresa

| Coluna | Origem | Descrição |
|---|---|---|
| Cód. Empresa | `N_EMPRESA.CODEMPRESA` | Codigo da empresa |
| Empresa | `N_EMPRESA.RAZAOSOCIAL` | Razao social da empresa |

### dMotivo

| Coluna | Origem | Descrição |
|---|---|---|
| Cód. Motivo | `F_MOTIVO_DESLIGAMENTO.CODMOTIVO` | Codigo do motivo de desligamento |
| Motivo | `F_MOTIVO_DESLIGAMENTO.DESCRICAOMOTIVO` | Descricao do motivo de desligamento |

### fDesligamento

| Coluna | Origem | Descrição |
|---|---|---|
| Data do Desligamento | `F_DESLIGAMENTO.DATADESLIGAMENTO` | Data de desligamento do colaborador |
| MATRICULA (oculta) | `F_DESLIGAMENTO.MATRICULA` | Matricula do colaborador |
| CODMOTIVO (oculta) | `F_DESLIGAMENTO.CODMOTIVO` | Codigo do motivo de deligamento |


## Relacionamentos

| De (muitos) | Para (um) | Estado | Prova |
|---|---|---|---|
| fDesligamento[Data do Desligamento] | dCalendario[Data] | ativa | calendário (gerado) |
| dColaborador[CODCARGO] | dCargo[Cód. Cargo] | ativa | constraint (FK_F_FUNCIONARIO_F_CARGO_CODCARGO) |
| dColaborador[CODEMPRESA] | dEmpresa[Cód. Empresa] | ativa | constraint (FK_F_FUNCIONARIO_N_EMPRESA_CODEMPRESA) |
| fDesligamento[MATRICULA] | dColaborador[Matrícula] | ativa | constraint (FK_F_DESLIGAMENTO_F_FUNCIONARIO_MATRICULA) |
| fDesligamento[CODMOTIVO] | dMotivo[Cód. Motivo] | ativa | constraint (FK_F_DESLIGAMENTO_F_MOTIVO_DESLIGAMENTO_CODMOTIVO) |

## Histórico de mudanças

### 1.0 — 27/10/2026 12:43 — aprovado por Teste
- primeira versão aprovada

