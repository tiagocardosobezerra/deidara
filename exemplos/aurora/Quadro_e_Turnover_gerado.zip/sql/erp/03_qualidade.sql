﻿/*
  Quadro e Turnover — qualidade dos dados antes da primeira atualização
  Gerado pelo Deidara a partir do argila.json aprovado.
  Cada linha deve trazer ocorrencias = 0. Diferente de zero:
    chave_repetida  -> o Power BI recusa a relação (lado "um" com duplicata);
    orfaos          -> linhas da fato sem par na dimensão (somem do corte, aparecem como "(Em branco)");
    fora_calendario -> datas fora do intervalo do calendário (somem dos gráficos de tempo).
*/
SET NOCOUNT ON;

SELECT N'fora_calendario' AS checagem, N'fDesligamento[Data do Desligamento] -> dCalendario[Data]' AS onde, COUNT_BIG(*) AS ocorrencias FROM [bi].[vw_fDesligamento] WHERE [Data do Desligamento] < '20200101' OR [Data do Desligamento] > '20261231'
UNION ALL
SELECT N'chave_repetida' AS checagem, N'dColaborador[CODCARGO] -> dCargo[Cód. Cargo]' AS onde, COUNT_BIG(*) AS ocorrencias FROM (SELECT [Cód. Cargo] FROM [bi].[vw_dCargo] GROUP BY [Cód. Cargo] HAVING COUNT_BIG(*) > 1) AS x
UNION ALL
SELECT N'orfaos' AS checagem, N'dColaborador[CODCARGO] -> dCargo[Cód. Cargo]' AS onde, COUNT_BIG(*) AS ocorrencias FROM [bi].[vw_dColaborador] AS f WHERE f.[CODCARGO] IS NOT NULL AND NOT EXISTS (SELECT 1 FROM [bi].[vw_dCargo] AS d WHERE d.[Cód. Cargo] = f.[CODCARGO])
UNION ALL
SELECT N'chave_repetida' AS checagem, N'dColaborador[CODEMPRESA] -> dEmpresa[Cód. Empresa]' AS onde, COUNT_BIG(*) AS ocorrencias FROM (SELECT [Cód. Empresa] FROM [bi].[vw_dEmpresa] GROUP BY [Cód. Empresa] HAVING COUNT_BIG(*) > 1) AS x
UNION ALL
SELECT N'orfaos' AS checagem, N'dColaborador[CODEMPRESA] -> dEmpresa[Cód. Empresa]' AS onde, COUNT_BIG(*) AS ocorrencias FROM [bi].[vw_dColaborador] AS f WHERE f.[CODEMPRESA] IS NOT NULL AND NOT EXISTS (SELECT 1 FROM [bi].[vw_dEmpresa] AS d WHERE d.[Cód. Empresa] = f.[CODEMPRESA])
UNION ALL
SELECT N'chave_repetida' AS checagem, N'fDesligamento[MATRICULA] -> dColaborador[Matrícula]' AS onde, COUNT_BIG(*) AS ocorrencias FROM (SELECT [Matrícula] FROM [bi].[vw_dColaborador] GROUP BY [Matrícula] HAVING COUNT_BIG(*) > 1) AS x
UNION ALL
SELECT N'orfaos' AS checagem, N'fDesligamento[MATRICULA] -> dColaborador[Matrícula]' AS onde, COUNT_BIG(*) AS ocorrencias FROM [bi].[vw_fDesligamento] AS f WHERE f.[MATRICULA] IS NOT NULL AND NOT EXISTS (SELECT 1 FROM [bi].[vw_dColaborador] AS d WHERE d.[Matrícula] = f.[MATRICULA])
UNION ALL
SELECT N'chave_repetida' AS checagem, N'fDesligamento[CODMOTIVO] -> dMotivo[Cód. Motivo]' AS onde, COUNT_BIG(*) AS ocorrencias FROM (SELECT [Cód. Motivo] FROM [bi].[vw_dMotivo] GROUP BY [Cód. Motivo] HAVING COUNT_BIG(*) > 1) AS x
UNION ALL
SELECT N'orfaos' AS checagem, N'fDesligamento[CODMOTIVO] -> dMotivo[Cód. Motivo]' AS onde, COUNT_BIG(*) AS ocorrencias FROM [bi].[vw_fDesligamento] AS f WHERE f.[CODMOTIVO] IS NOT NULL AND NOT EXISTS (SELECT 1 FROM [bi].[vw_dMotivo] AS d WHERE d.[Cód. Motivo] = f.[CODMOTIVO]);
