﻿/*
  Quadro e Turnover — camada de views para o Power BI (fonte erp, banco AURORA)
  Gerado pelo Deidara a partir do argila.json aprovado.
  Revise com o DBA antes de rodar. Só leitura: nenhuma view altera dado.
  Requer SQL Server 2016 SP1 ou superior (CREATE OR ALTER).
*/
SET NOCOUNT ON;

IF SCHEMA_ID(N'bi') IS NULL
    EXEC(N'CREATE SCHEMA [bi] AUTHORIZATION dbo');
GO

-- Colaboradores da empresa
-- origem: dbo.F_FUNCIONARIO
CREATE OR ALTER VIEW [bi].[vw_dColaborador]
AS
SELECT
    t.[MATRICULA] AS [Matrícula],
    t.[NOME] AS [Colaborador],
    t.[DATAADMISSAO] AS [Data de Admissão],
    t.[VALORREMUNERACAO] AS [Remuneração],
    t.[CODCARGO] AS [CODCARGO],
    t.[CODEMPRESA] AS [CODEMPRESA]
FROM [dbo].[F_FUNCIONARIO] AS t;
GO

-- Cargos dos colaboradores
-- origem: dbo.F_CARGO
CREATE OR ALTER VIEW [bi].[vw_dCargo]
AS
SELECT
    t.[CODCARGO] AS [Cód. Cargo],
    t.[DESCRICAOCARGO] AS [Cargo]
FROM [dbo].[F_CARGO] AS t;
GO

-- Empresas cadastradas no grupo
-- origem: dbo.N_EMPRESA
CREATE OR ALTER VIEW [bi].[vw_dEmpresa]
AS
SELECT
    t.[CODEMPRESA] AS [Cód. Empresa],
    t.[RAZAOSOCIAL] AS [Empresa]
FROM [dbo].[N_EMPRESA] AS t;
GO

-- Motivos de desligamento do colaborador
-- origem: dbo.F_MOTIVO_DESLIGAMENTO
CREATE OR ALTER VIEW [bi].[vw_dMotivo]
AS
SELECT
    t.[CODMOTIVO] AS [Cód. Motivo],
    t.[DESCRICAOMOTIVO] AS [Motivo]
FROM [dbo].[F_MOTIVO_DESLIGAMENTO] AS t;
GO

-- Dados de deligamento contratual do colaborador
-- origem: dbo.F_DESLIGAMENTO
CREATE OR ALTER VIEW [bi].[vw_fDesligamento]
AS
SELECT
    CAST(t.[DATADESLIGAMENTO] AS date) AS [Data do Desligamento],
    t.[MATRICULA] AS [MATRICULA],
    t.[CODMOTIVO] AS [CODMOTIVO]
FROM [dbo].[F_DESLIGAMENTO] AS t;
GO

-- Permissão de leitura para a conta que o Power BI (gateway) usa:
-- GRANT SELECT ON SCHEMA::[bi] TO [conta_do_gateway];
