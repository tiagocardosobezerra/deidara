﻿/*
  Quadro e Turnover — conferência dos indicadores (homologação)
  Gerado pelo Deidara a partir do argila.json aprovado.
  Rode depois de criar as views. Compare cada total com o cartão do Power BI
  sem nenhum segmentador marcado; o bloco por ano, com o segmentador de Ano.
  Divisão, tempo e DAX livre não entram: confira pelos componentes.
*/
SET NOCOUNT ON;

-- 1) Total geral
SELECT N'Cadastros' AS indicador, CAST(COUNT_BIG(*) AS decimal(38,6)) AS total_no_banco FROM [bi].[vw_dColaborador]
UNION ALL
SELECT N'Remuneração Total' AS indicador, CAST(SUM(CAST([Remuneração] AS decimal(38,6))) AS decimal(38,6)) AS total_no_banco FROM [bi].[vw_dColaborador]
UNION ALL
SELECT N'Desligamentos' AS indicador, CAST(COUNT_BIG(*) AS decimal(38,6)) AS total_no_banco FROM [bi].[vw_fDesligamento];

-- 2) Por ano (data ativa do calendário)
SELECT N'Desligamentos' AS indicador, YEAR([Data do Desligamento]) AS ano, CAST(COUNT_BIG(*) AS decimal(38,6)) AS total_no_banco FROM [bi].[vw_fDesligamento] GROUP BY YEAR([Data do Desligamento])
ORDER BY indicador, ano;

-- 3) Headcount: estoque no último dia de cada mês (compare com o visual por mês, mês a mês)
WITH n AS (SELECT TOP (24) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS k FROM sys.all_objects),
     f AS (SELECT EOMONTH(GETDATE(), -k) AS fim_do_mes FROM n)
SELECT N'Headcount' AS indicador, f.fim_do_mes,
       (SELECT COUNT_BIG(*) FROM [bi].[vw_dColaborador] AS e WHERE e.[Data de Admissão] <= f.fim_do_mes)
     - (SELECT COUNT_BIG(*) FROM [bi].[vw_fDesligamento] AS s WHERE s.[Data do Desligamento] <= f.fim_do_mes) AS total_no_banco
FROM f
ORDER BY f.fim_do_mes;

