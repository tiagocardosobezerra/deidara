﻿/*
  Quadro e Turnover — conferência dos indicadores (homologação)
  Gerado pelo Deidara a partir do argila.json aprovado.
  Rode depois de criar as views. Compare cada total com o cartão do Power BI
  sem nenhum segmentador marcado; o bloco por ano, com o segmentador de Ano.
  Divisão, tempo e DAX livre não entram: confira pelos componentes.
*/
SET NOCOUNT ON;

-- 1) Total geral
SELECT N'Cadastros' AS indicador, CAST(COUNT_BIG(*) AS decimal(38,6)) AS total_no_banco FROM [bi].[vw_dColaborador]
UNION ALL
SELECT N'Remuneração Total' AS indicador, CAST(SUM(CAST([Remuneração] AS decimal(38,6))) AS decimal(38,6)) AS total_no_banco FROM [bi].[vw_dColaborador]
UNION ALL
SELECT N'Desligamentos' AS indicador, CAST(COUNT_BIG(*) AS decimal(38,6)) AS total_no_banco FROM [bi].[vw_fDesligamento];

-- 2) Por ano (data ativa do calendário)
SELECT N'Desligamentos' AS indicador, YEAR([Data do Desligamento]) AS ano, CAST(COUNT_BIG(*) AS decimal(38,6)) AS total_no_banco FROM [bi].[vw_fDesligamento] GROUP BY YEAR([Data do Desligamento])
ORDER BY indicador, ano;

