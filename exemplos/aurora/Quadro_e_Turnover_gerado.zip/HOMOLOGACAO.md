# Quadro e Turnover — homologação

Painel aprovado por **Gestor de RH (exemplo)** em 27/10/2026 18:39. Preencha depois da primeira atualização no Power BI Desktop. Só publique com tudo marcado.

## 1. Qualidade dos dados

- [ ] `sql/erp/03_qualidade.sql` rodou e **todas as linhas deram 0** (chave repetida, órfãos, datas fora do calendário)
- [ ] ligação declarada fMeta[Cód. Empresa] → dEmpresa[Cód. Empresa]: a atualização não reclamou de valor duplicado, e o corte por ela não tem "(Em branco)" inesperado

## 2. Cada indicador bate com a fonte

Sem nenhum filtro marcado no painel. Para os de agregação simples, o total do banco sai de `02_conferencia.sql`; para os outros, confira os componentes (numerador e denominador).

| ✓ | Indicador | Onde ler no painel | Como conferir | Total na fonte | Total no painel |
|---|---|---|---|---|---|
| [ ] | Headcount | Visão Geral › Headcount | 02_conferencia.sql (um número por fim de mês) |  |  |
| [ ] | HC Médio | apoia Turnover | pelos componentes: Headcount |  |  |
| [ ] | Cadastros | apoia Remuneração Média | 02_conferencia.sql |  |  |
| [ ] | Remuneração Total | Visão Geral › Remuneração Total | 02_conferencia.sql |  |  |
| [ ] | Remuneração Média | Visão Geral › Remuneração Média | pelos componentes: Remuneração Total, Cadastros |  |  |
| [ ] | Desligamentos | Turnover › Desligamentos | 02_conferencia.sql |  |  |
| [ ] | Turnover | Turnover › Turnover | pelos componentes: Desligamentos, HC Médio |  |  |
| [ ] | Meta de Turnover | cor/meta de Turnover | na própria fonte (metas: Metas) |  |  |
| [ ] | Desligamentos Acum. Ano | Turnover › Desligamentos e Desligamentos Acum. Ano por Mês/Ano | pelos componentes: Desligamentos |  |  |
| [ ] | Var. Desligamentos A/A | Turnover › Var. Desligamentos A/A | pelos componentes: Desligamentos |  |  |

## 3. Cortes e metas

- [ ] cada segmentador muda os números esperados (e só eles)
- [ ] os indicadores com meta mostram a cor certa (verde = bateu a meta)
- [ ] o gestor viu o painel com dados reais e confirmou que os números fazem sentido

## 4. Publicação

- [ ] salvo como .pbix e publicado no workspace do time
- [ ] atualização agendada configurada (e gateway, se a fonte for local ou de rede)
- [ ] painel salvo no Memory Card (`deidara.py memory-card enviar ... --status em-uso`)
